# MpesaExpressApiService.STKPushResponseHeader

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**statusCode** | **String** | Status Code of the request, 0 - success | [optional] 
**statusDescription** | **String** | Status Code description | [optional] 


