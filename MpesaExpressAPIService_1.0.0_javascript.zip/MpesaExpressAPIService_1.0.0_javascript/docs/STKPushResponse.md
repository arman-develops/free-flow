# MpesaExpressApiService.STKPushResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**STKPushResponseHeader**](STKPushResponseHeader.md) |  | 
**response** | **Object** |  | 


